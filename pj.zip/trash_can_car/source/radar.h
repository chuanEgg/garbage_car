/*
 * radar.h
 *
 *  Created on: Apr 27, 2024
 *      Author: chuan
 */

#ifndef SOURCE_RADAR_H_
#define SOURCE_RADAR_H_

void radar_task(void *args);

#endif /* SOURCE_RADAR_H_ */
