# Garbage Car MakeNTU
Team: Toyota RAV4