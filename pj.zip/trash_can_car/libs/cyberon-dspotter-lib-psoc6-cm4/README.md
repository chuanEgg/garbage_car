# PSoC 6 MCU: Cyberon DSpotter Lib

Check out what's new for PSoC 6 about voice recognition.

Go to
- [Cyberon Voice Trigger Demo](https://github.com/CyberonEBU/cyberon-voice-trigger-demo-psoc6-cm4)
- [Cyberon Voice Trigger And Command Demo](https://github.com/CyberonEBU/cyberon-voice-trigger-and-command-demo-psoc6-cm4)
